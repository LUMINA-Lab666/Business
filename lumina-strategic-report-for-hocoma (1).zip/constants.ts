import { AlertTriangle, TrendingDown, ShieldAlert, Ban, Activity, CheckCircle, Globe, Anchor, FileWarning, Briefcase, Wrench } from 'lucide-react';
import { SlideData } from './types';

export const STOCK_DATA = [
  { date: '2023 Q3', value: 60870000, annotation: 'Market Cap $60.8M' },
  { date: '2024 Q1', value: 45000000, annotation: '' },
  { date: '2024 Q3', value: 15000000, annotation: 'Liquidity Crisis' },
  { date: '2024 Q4', value: 3300000, annotation: 'Emergency Debt' },
  { date: '2025 Q1', value: 1000000, annotation: 'Crash' },
  { date: '2025 Nov', value: 1000, annotation: 'Delisted ($1K)' },
];

export const SLIDES: SlideData[] = [
  {
    id: 'cover',
    title: 'THE SAFETY OF DECISION',
    subtitle: '2025 Global Intelligent Rehab Market & Supply Chain Risk Assessment',
    layout: 'cover',
    content: {
      text: 'CONFIDENTIAL INTELLIGENCE BRIEFING',
      source: 'LUMINA STRATEGIC INTELLIGENCE DIVISION'
    }
  },
  {
    id: 'overview',
    title: 'The Reality: Giants Falling',
    subtitle: 'DIH Holding (Hocoma Parent Co.) Market Collapse',
    layout: 'chart',
    content: {
      text: 'Commercial history teaches us that past glory does not guarantee future survival. DIH Holding has been forcibly delisted from NASDAQ as of Nov 2025. This is not just a stock ticker disappearing; it represents the complete severance of financing channels.',
      source: 'Data Sources: NASDAQ, SEC Filings, MarketBeat'
    },
    chartData: STOCK_DATA
  },
  {
    id: 'evidence',
    title: 'The Evidence',
    subtitle: 'Official Legal & Corporate Disclosures',
    layout: 'evidence',
    documents: [
      {
        title: "SEC FORM 8-K",
        date: "Nov 07, 2025",
        header: "UNITED STATES SECURITIES AND EXCHANGE COMMISSION",
        body: "Item 8.01 Other Events. On November 5, 2025, the Company received a Staff Delisting Determination... The Board has reviewed the company's financial position and",
        highlight: "determined to suspend its operations due to the inability to secure additional capital.",
        sourceUrl: "https://www.sec.gov/Archives/edgar/data/1883788/000149315225020954/form8-k.htm"
      },
      {
        title: "PARTNER TERMINATION",
        date: "Current Status",
        header: "Reha Technology AG Public Announcement",
        body: "Reha Technology AG announces the immediate termination of the distribution agreement with Hocoma AG. The decision was made after repeated failures to meet obligations.",
        highlight: "HOCOMA did not comply with its contractual agreements.",
        sourceUrl: "https://www.rehatechnology.com/en/reha-technology-ag-ceases-operations-with-immediate-effect/"
      }
    ],
    content: {
      source: "Sources: U.S. SEC Edgar Database; Reha Technology Corporate News"
    }
  },
  {
    id: 'impact',
    title: 'The Impact',
    subtitle: 'What This Means for Indonesian Healthcare Providers',
    layout: 'grid',
    cards: [
      {
        title: 'Supply Chain Break',
        description: 'Parent company suspension means global logistics halt. A single failed chip could leave million-dollar equipment permanently offline.',
        icon: Wrench,
        status: 'danger'
      },
      {
        title: 'Financial Risk',
        description: 'Any prepayments made now face high probability of being unrecoverable as the entity enters potential liquidation.',
        icon: Briefcase,
        status: 'danger'
      },
      {
        title: 'Asset Value Zero',
        description: 'Without OEM support and software updates, equipment becomes a "negative asset" with zero resale value.',
        icon: TrendingDown,
        status: 'danger'
      }
    ]
  },
  {
    id: 'solution',
    title: 'The Solution: Certainty',
    subtitle: 'LUMINA (Procare Meditech) — The Safe Harbor',
    layout: 'comparison',
    cards: [
      {
        title: 'Financial Stability',
        description: 'Healthy cash flow with zero reliance on volatile capital markets. 2025 Dubai Arab Health orders exceeded targets.',
        icon: Anchor,
        status: 'success'
      },
      {
        title: 'Full-Stack R&D',
        description: 'We own the core technology from software to hardware. 200+ Patents. "Five-Axis Linkage" proprietary tech.',
        icon: Activity,
        status: 'success'
      },
      {
        title: 'Local Commitment',
        description: 'Direct service team based in Jakarta. 24-hour response guarantee regardless of global market fluctuations.',
        icon: CheckCircle,
        status: 'success'
      }
    ]
  },
  {
    id: 'conclusion',
    title: 'SAFE HARBOR PROGRAM',
    subtitle: 'Protect Your Medical Assets',
    layout: 'end',
    content: {
      text: 'Decision making is about choosing the future. Do not buy into the past.',
      highlight: 'We invite you to the Safe Harbor Program: Risk-free transition for affected hospitals.',
      bullets: [
        'Free On-Site Risk Assessment',
        'Trade-in Subsidies for Hocoma Intenders',
        '5-Year Worry-Free Warranty'
      ]
    }
  }
];