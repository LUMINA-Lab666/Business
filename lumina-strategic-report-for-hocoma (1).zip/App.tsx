import React, { useState, useEffect, useCallback } from 'react';
import { Layout } from './components/Layout';
import { RiskChart } from './components/RiskChart';
import { SLIDES } from './constants';
import { SlideData } from './types';
import { AlertCircle, ArrowRight, ShieldCheck, FileText, ExternalLink, Siren, Shield, Globe, MessageCircle } from 'lucide-react';

const SlideContent: React.FC<{ slide: SlideData }> = ({ slide }) => {
  // Fade in animation key
  const animationClass = "animate-[fadeIn_0.6s_ease-out_forwards]";

  switch (slide.layout) {
    case 'cover':
      return (
        <div className={`flex flex-col justify-center items-center h-full text-center ${animationClass} relative`}>
          {/* Epic Background Effect for Cover */}
          <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
             {/* Red Pulse */}
             <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-red-900/20 rounded-full blur-[120px] animate-pulse"></div>
             {/* World Map Grid (Simulated) */}
             <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:40px_40px] opacity-20"></div>
          </div>

          <div className="relative z-10 mb-8 animate-bounce duration-[2000ms]">
             <div className="relative p-6 rounded-2xl bg-slate-900/80 border border-red-500/30 backdrop-blur-md shadow-[0_0_50px_rgba(239,68,68,0.2)]">
                <Siren className="w-20 h-20 text-red-500" />
             </div>
          </div>
          
          <h1 className="relative z-10 text-5xl md:text-8xl font-black text-white mb-6 max-w-5xl leading-none tracking-tighter uppercase drop-shadow-2xl">
            <span className="text-transparent bg-clip-text bg-gradient-to-b from-white to-slate-400">
              The Safety of
            </span>
            <br />
            <span className="text-red-500">Decision</span>
          </h1>
          
          <h2 className="relative z-10 text-xl md:text-2xl text-slate-300 font-mono mb-12 max-w-3xl border-y border-slate-700 py-4 bg-black/30 backdrop-blur-sm">
            {slide.subtitle}
          </h2>
          
          <div className="relative z-10 flex flex-col items-center gap-3">
            <p className="text-sm text-red-500 tracking-[0.3em] uppercase font-bold flex items-center gap-2">
              <span className="w-2 h-2 bg-red-500 rounded-full animate-ping"></span>
              {slide.content?.source}
            </p>
            <p className="text-[10px] text-slate-600 font-mono uppercase tracking-widest">
              Authorized Personnel Only • 2025 Strategy Brief
            </p>
          </div>
        </div>
      );

    case 'chart':
      return (
        <div className={`h-full flex flex-col ${animationClass}`}>
          <div className="mb-8 pl-6 border-l-4 border-red-500">
            <h2 className="text-3xl md:text-5xl font-bold text-slate-100 mb-2">{slide.title}</h2>
            <p className="text-lg text-red-400 font-medium">{slide.subtitle}</p>
          </div>
          <div className="flex-1 flex flex-col md:flex-row gap-8 items-start">
            <div className="flex-1 w-full relative group">
               <div className="absolute inset-0 bg-red-500/5 blur-xl group-hover:bg-red-500/10 transition-all duration-700"></div>
               <div className="relative z-10 h-full">
                 {slide.chartData && <RiskChart data={slide.chartData} />}
               </div>
            </div>
            <div className="md:w-1/3 bg-slate-900/80 p-8 rounded-xl border border-red-900/30 backdrop-blur-sm self-stretch flex flex-col justify-center shadow-2xl">
              <p className="text-xl leading-relaxed text-slate-300 mb-4 font-light">
                {slide.content?.text}
              </p>
              {slide.content?.source && (
                <div className="mt-auto pt-4 border-t border-slate-800 text-xs text-slate-500 font-mono">
                  {slide.content.source}
                </div>
              )}
            </div>
          </div>
        </div>
      );

    case 'evidence':
      return (
        <div className={`h-full flex flex-col ${animationClass}`}>
          <div className="mb-8 text-center md:text-left flex items-center gap-4">
             <div className="p-3 bg-slate-800 rounded-lg">
                <FileText className="w-8 h-8 text-slate-200" />
             </div>
             <div>
               <h2 className="text-3xl md:text-4xl font-bold text-slate-100">{slide.title}</h2>
               <p className="text-xl text-slate-400">{slide.subtitle}</p>
             </div>
          </div>

          <div className="flex-1 flex flex-col md:flex-row gap-8 justify-center items-center perspective-[1000px]">
            {slide.documents?.map((doc, idx) => (
              <div 
                key={idx} 
                className={`relative w-full max-w-lg group transition-all duration-500 hover:z-50 hover:scale-105 ${idx % 2 === 0 ? 'rotate-[-2deg]' : 'rotate-[2deg]'}`}
              >
                {/* Paper Shadow */}
                <div className="absolute top-4 left-4 w-full h-full bg-black/50 blur-lg rounded-sm transform translate-y-4 pointer-events-none"></div>
                
                {/* Document Container */}
                <div className="relative bg-[#f4f4f5] text-slate-900 p-8 rounded-sm shadow-2xl h-[450px] flex flex-col overflow-hidden border border-slate-300">
                   {/* Realistic Paper Texture Overlay */}
                   <div className="absolute inset-0 opacity-[0.03] bg-[url('https://www.transparenttextures.com/patterns/cardboard.png')] pointer-events-none"></div>

                   {/* Header Area */}
                   <div className="border-b-2 border-black pb-4 mb-6 flex justify-between items-start">
                      <div className="w-16 h-16 border-2 border-black flex items-center justify-center rounded-full opacity-80">
                         <div className="w-10 h-10 border border-black rounded-full"></div>
                      </div>
                      <div className="text-right">
                         <div className="font-mono text-xs text-slate-500 uppercase tracking-widest mb-1">{doc.date}</div>
                         <div className="font-bold text-xs bg-black text-white px-3 py-1 inline-block">{doc.title}</div>
                      </div>
                   </div>

                   {/* Content Area */}
                   <div className="flex-1 font-serif relative">
                      <h4 className="font-bold text-sm mb-4 uppercase tracking-wide text-slate-900 border-b border-slate-300 pb-2 inline-block">{doc.header}</h4>
                      <p className="text-sm leading-loose text-slate-800 font-serif text-justify">
                        {doc.body} 
                      </p>
                      <div className="mt-4 p-4 bg-yellow-100/50 border-l-4 border-red-500 italic text-sm text-slate-900 font-medium relative">
                        <span className="absolute -left-2 top-0 text-red-500 text-2xl leading-none">"</span>
                        {doc.highlight}
                      </div>
                   </div>

                   {/* Footer / Watermark */}
                   <div className="mt-6 pt-4 border-t border-slate-300 flex justify-between items-center opacity-40">
                      <span className="text-[10px] font-mono tracking-[0.2em] text-red-900 font-bold">CONFIDENTIAL</span>
                      <span className="font-serif italic text-xs">Page 1 of 1</span>
                   </div>
                   
                   {/* Stamp Overlay */}
                   <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 border-4 border-red-900/20 text-red-900/20 font-black text-5xl p-4 rotate-[-15deg] pointer-events-none uppercase tracking-widest whitespace-nowrap z-0">
                      VERIFIED
                   </div>
                </div>
                
                <div className="mt-6 text-center transform-style-3d translate-z-[50px]">
                   <a 
                     href={doc.sourceUrl} 
                     target="_blank" 
                     rel="noopener noreferrer" 
                     className="relative z-50 pointer-events-auto inline-flex items-center gap-2 px-6 py-3 bg-slate-800 hover:bg-slate-700 text-cyan-400 text-xs font-bold rounded-full border border-slate-600 transition-all uppercase tracking-wider shadow-lg hover:shadow-cyan-900/20 hover:scale-105"
                   >
                      <ExternalLink size={14} /> Open Original Document
                   </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      );

    case 'grid':
    case 'comparison':
      return (
        <div className={`h-full flex flex-col ${animationClass}`}>
          <div className="mb-10 text-center md:text-left">
            <h2 className="text-3xl md:text-5xl font-bold text-slate-100 mb-3">{slide.title}</h2>
            <p className="text-xl text-slate-400 max-w-2xl">{slide.subtitle}</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 flex-1 content-center">
            {slide.cards?.map((card, idx) => {
              const Icon = card.icon || AlertCircle;
              const statusColors = {
                danger: 'border-red-500/30 bg-gradient-to-br from-red-950/20 to-slate-900 hover:border-red-500/60',
                warning: 'border-amber-500/30 bg-gradient-to-br from-amber-950/20 to-slate-900',
                success: 'border-cyan-500/30 bg-gradient-to-br from-cyan-950/20 to-slate-900 hover:border-cyan-400/60',
                neutral: 'border-slate-700 bg-slate-900/30',
              };
              const iconColors = {
                danger: 'text-red-500 bg-red-500/10 shadow-[0_0_15px_rgba(239,68,68,0.3)]',
                warning: 'text-amber-500 bg-amber-500/10',
                success: 'text-cyan-400 bg-cyan-400/10 shadow-[0_0_15px_rgba(34,211,238,0.3)]',
                neutral: 'text-slate-400 bg-slate-400/10',
              };

              return (
                <div 
                  key={idx} 
                  className={`p-8 rounded-2xl border backdrop-blur-md transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl flex flex-col ${statusColors[card.status || 'neutral']}`}
                >
                  <div className={`mb-6 p-4 w-16 h-16 rounded-2xl flex items-center justify-center ${iconColors[card.status || 'neutral']}`}>
                    <Icon size={32} strokeWidth={1.5} />
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-4">{card.title}</h3>
                  <p className="text-slate-400 text-sm leading-relaxed flex-1">
                    {card.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      );

    case 'content':
    case 'end':
      const isEnd = slide.layout === 'end';
      return (
        <div className={`h-full flex flex-col justify-center items-center ${animationClass} relative`}>
           {isEnd && (
             <div className="absolute inset-0 overflow-hidden pointer-events-none">
                {/* Safe Harbor Calm Blue Glow */}
                <div className="absolute top-[20%] right-[-10%] w-[600px] h-[600px] bg-cyan-500/10 rounded-full blur-[100px]"></div>
                <div className="absolute bottom-[-10%] left-[-10%] w-[600px] h-[600px] bg-blue-600/10 rounded-full blur-[100px]"></div>
             </div>
           )}

           <div className="max-w-5xl w-full relative z-10">
              <div className="mb-8 text-center">
                <h2 className={`${isEnd ? 'text-5xl md:text-7xl bg-clip-text text-transparent bg-gradient-to-r from-cyan-200 via-white to-cyan-200 drop-shadow-[0_0_10px_rgba(34,211,238,0.5)]' : 'text-3xl md:text-4xl text-slate-100'} font-black mb-4 tracking-tight uppercase`}>
                  {slide.title}
                </h2>
                <p className="text-xl md:text-2xl text-slate-400 font-light">{slide.subtitle}</p>
              </div>

              <div className="bg-slate-900/60 border border-slate-700/50 p-8 md:p-10 rounded-3xl w-full backdrop-blur-lg shadow-2xl relative overflow-hidden">
                {/* Decorative Elements */}
                {isEnd && <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-cyan-500 to-transparent"></div>}
                
                {slide.content?.highlight && (
                  <div className={`mb-8 p-6 rounded-xl ${isEnd ? 'bg-cyan-950/30 border border-cyan-500/30' : 'bg-slate-800 border-l-4 border-cyan-500'} text-center`}>
                    <p className={`text-xl md:text-2xl font-medium italic ${isEnd ? 'text-cyan-100' : 'text-slate-200'}`}>
                      "{slide.content.highlight}"
                    </p>
                  </div>
                )}
                
                {slide.content?.text && (
                  <p className="text-lg md:text-xl text-slate-300 leading-relaxed mb-8 text-center max-w-3xl mx-auto">
                    {slide.content.text}
                  </p>
                )}

                {slide.content?.bullets && (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    {slide.content.bullets.map((bullet, i) => (
                      <div key={i} className={`p-6 rounded-xl border ${isEnd ? 'border-cyan-500/20 bg-cyan-950/20' : 'border-slate-700 bg-slate-800/50'} text-center group hover:bg-cyan-900/20 transition-colors`}>
                        <div className={`mx-auto mb-4 w-12 h-12 rounded-full flex items-center justify-center ${isEnd ? 'bg-cyan-500/20 text-cyan-400' : 'bg-red-500/20 text-red-400'} group-hover:scale-110 transition-transform`}>
                           {i === 0 ? <Shield className="w-6 h-6" /> : i === 1 ? <Siren className="w-6 h-6" /> : <Globe className="w-6 h-6" />}
                        </div>
                        <span className="text-slate-200 font-medium">{bullet}</span>
                      </div>
                    ))}
                  </div>
                )}

                {isEnd && (
                  <div className="pt-8 border-t border-slate-800 flex flex-col md:flex-row gap-8 items-center justify-center">
                    <a 
                      href="https://www.lumina-meditech.net#contact" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="px-10 py-5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold rounded-xl transition-all shadow-[0_0_30px_rgba(8,145,178,0.4)] hover:shadow-[0_0_50px_rgba(8,145,178,0.6)] tracking-wide uppercase text-sm flex items-center gap-3"
                    >
                      <ShieldCheck className="w-5 h-5" />
                      Initialize Safe Harbor Protocol
                    </a>
                  </div>
                )}
              </div>
           </div>
        </div>
      );

    default:
      return null;
  }
};

const App: React.FC = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const nextSlide = useCallback(() => {
    setCurrentSlide((prev) => Math.min(prev + 1, SLIDES.length - 1));
  }, []);

  const prevSlide = useCallback(() => {
    setCurrentSlide((prev) => Math.max(prev - 1, 0));
  }, []);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === 'Space' || e.key === 'Enter') {
        nextSlide();
      } else if (e.key === 'ArrowLeft') {
        prevSlide();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [nextSlide, prevSlide]);

  return (
    <Layout
      currentSlide={currentSlide}
      totalSlides={SLIDES.length}
      nextSlide={nextSlide}
      prevSlide={prevSlide}
      title={SLIDES[currentSlide].title}
    >
      <div key={currentSlide} className="w-full h-full">
        <SlideContent slide={SLIDES[currentSlide]} />
      </div>
    </Layout>
  );
};

export default App;