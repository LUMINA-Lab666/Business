import { LucideIcon } from 'lucide-react';

export interface SlideData {
  id: string;
  title: string;
  subtitle?: string;
  layout: 'cover' | 'content' | 'chart' | 'grid' | 'comparison' | 'end' | 'evidence';
  content?: {
    text?: string;
    bullets?: string[];
    highlight?: string;
    source?: string;
    contact?: {
      whatsapp: string;
      whatsappUrl: string;
    };
  };
  chartData?: any[];
  documents?: {
    title: string;
    date: string;
    header: string;
    body: string;
    highlight: string;
    sourceUrl: string;
  }[];
  cards?: {
    title: string;
    description: string;
    icon?: LucideIcon;
    status?: 'danger' | 'warning' | 'success' | 'neutral';
  }[];
}

export interface ChartDataPoint {
  date: string;
  value: number;
  annotation?: string;
}