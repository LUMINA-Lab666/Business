import React from 'react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { ChartDataPoint } from '../types';

interface RiskChartProps {
  data: ChartDataPoint[];
}

export const RiskChart: React.FC<RiskChartProps> = ({ data }) => {
  return (
    <div className="w-full h-[400px] mt-8 bg-slate-900/30 p-6 rounded-xl border border-slate-800 backdrop-blur-sm">
      <h3 className="text-lg font-semibold text-slate-300 mb-6 pl-2 border-l-4 border-red-500">
        Market Capitalization Trend (2023-2025)
      </h3>
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart
          data={data}
          margin={{
            top: 10,
            right: 30,
            left: 0,
            bottom: 0,
          }}
        >
          <defs>
            <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#ef4444" stopOpacity={0.4} />
              <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
          <XAxis 
            dataKey="date" 
            stroke="#64748b" 
            tick={{ fill: '#64748b', fontSize: 12 }} 
            tickLine={false}
            axisLine={false}
          />
          <YAxis 
            stroke="#64748b" 
            tick={{ fill: '#64748b', fontSize: 12 }} 
            tickFormatter={(value) => `$${value / 1000000}M`}
            tickLine={false}
            axisLine={false}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: '#0f172a',
              border: '1px solid #1e293b',
              borderRadius: '8px',
              color: '#f8fafc',
            }}
            formatter={(value: number) => [`$${value.toLocaleString()}`, 'Market Cap']}
            labelStyle={{ color: '#94a3b8' }}
          />
          <Area
            type="monotone"
            dataKey="value"
            stroke="#ef4444"
            strokeWidth={3}
            fill="url(#colorValue)"
            animationDuration={2000}
          />
        </AreaChart>
      </ResponsiveContainer>
      <div className="flex justify-between items-center mt-4 px-4 text-xs text-slate-500">
        <span className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-red-500"></span>
          DIH Market Cap
        </span>
        <span className="italic">Note: Data based on public market disclosures (Approximate values)</span>
      </div>
    </div>
  );
};