import React, { ReactNode } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface LayoutProps {
  children: ReactNode;
  currentSlide: number;
  totalSlides: number;
  nextSlide: () => void;
  prevSlide: () => void;
  title: string;
}

const LuminaLogo = () => (
  <div className="flex flex-col items-center justify-center leading-none select-none shrink-0 cursor-default">
    {/* Text Logo Only */}
    <div className="flex flex-col items-center">
      <h1 className="text-3xl md:text-4xl font-bold tracking-[0.1em] text-cyan-400 font-sans whitespace-nowrap drop-shadow-[0_0_15px_rgba(34,211,238,0.4)]">
        LUM<span className="text-[0.9em]">i</span>NA
      </h1>
      <div className="flex items-center gap-2 opacity-90 w-full justify-between mt-1">
        <div className="h-px flex-1 bg-gradient-to-r from-transparent via-slate-500 to-slate-500"></div>
        <span className="text-[0.55rem] md:text-[0.65rem] uppercase tracking-[0.2em] text-slate-400 font-medium whitespace-nowrap px-1">
          PROCARE MEDITECH
        </span>
        <div className="h-px flex-1 bg-gradient-to-l from-transparent via-slate-500 to-slate-500"></div>
      </div>
    </div>
  </div>
);

export const Layout: React.FC<LayoutProps> = ({
  children,
  currentSlide,
  totalSlides,
  nextSlide,
  prevSlide,
  title,
}) => {
  const progress = ((currentSlide + 1) / totalSlides) * 100;

  return (
    <div className="relative w-full h-screen bg-slate-950 text-slate-200 overflow-hidden flex flex-col selection:bg-cyan-500/30">
      {/* Background Ambience */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-cyan-900/10 rounded-full blur-[100px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-900/10 rounded-full blur-[100px]" />
        <div className="absolute top-[20%] right-[20%] w-[20%] h-[20%] bg-indigo-900/5 rounded-full blur-[80px]" />
      </div>

      {/* Header */}
      <header className="relative z-10 w-full px-8 py-6 flex justify-between items-center border-b border-slate-800/50 backdrop-blur-sm shrink-0">
        <div className="flex items-center gap-3">
          <LuminaLogo />
        </div>
        <div className="hidden md:block text-xs md:text-sm font-light text-slate-500 tracking-widest uppercase border-l border-slate-800 pl-4 whitespace-nowrap overflow-hidden text-ellipsis">
          {title}
        </div>
      </header>

      {/* Main Content Area */}
      <main className="relative z-10 flex-1 flex flex-col justify-center items-center p-6 md:p-12 w-full max-w-7xl mx-auto overflow-hidden">
        <div className="w-full h-full flex flex-col">
          {children}
        </div>
      </main>

      {/* Footer / Controls */}
      <footer className="relative z-10 w-full p-6 flex justify-between items-center border-t border-slate-800/50 backdrop-blur-sm shrink-0">
        <div className="flex flex-col md:flex-row md:items-center gap-1 md:gap-4 text-[10px] md:text-xs text-slate-600 font-mono">
          <span>SECURE VIEW: {currentSlide + 1} <span className="text-slate-800 mx-1">/</span> {totalSlides}</span>
          <span className="hidden md:inline text-slate-800">|</span>
          <span>HQ: JAKARTA, INDONESIA</span>
        </div>

        {/* Progress Bar */}
        <div className="absolute bottom-0 left-0 h-1 bg-gradient-to-r from-cyan-600 to-blue-700 transition-all duration-500 ease-out" style={{ width: `${progress}%` }} />

        {/* Nav Controls */}
        <div className="flex gap-2">
          <button
            onClick={prevSlide}
            disabled={currentSlide === 0}
            className="p-3 rounded-full hover:bg-slate-800 transition-colors disabled:opacity-30 disabled:cursor-not-allowed group"
          >
            <ChevronLeft className="w-6 h-6 text-cyan-400 group-hover:scale-110 transition-transform" />
          </button>
          <button
            onClick={nextSlide}
            disabled={currentSlide === totalSlides - 1}
            className="p-3 rounded-full hover:bg-slate-800 transition-colors disabled:opacity-30 disabled:cursor-not-allowed group"
          >
            <ChevronRight className="w-6 h-6 text-cyan-400 group-hover:scale-110 transition-transform" />
          </button>
        </div>
      </footer>
    </div>
  );
};